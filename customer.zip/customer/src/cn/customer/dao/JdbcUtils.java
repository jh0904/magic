package cn.customer.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class JdbcUtils {
	
	//配置文件的默认配置，要求必须给出c3p0-config.xml文件
	private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
	
	//private static Connection conn = null;
	private static ThreadLocal<Connection>  tl = new ThreadLocal<Connection>();
	//使用连接池返回一个连接对象
	public static Connection getConn() throws SQLException{
		Connection conn = tl.get();
		if(conn != null){//不等于null，直接返回
			return conn;
		}
		return dataSource.getConnection();
	}
	//返回连接池对象dataSource
	public static DataSource getDataSource(){
		return dataSource;
	}
	//开启事务    多个事务同时来调用此方法
	public static void beginTransaction() throws SQLException{
		Connection conn = tl.get();
		if(conn != null){
			throw new SQLException("已经开启了事务，就不要重复开启了");
		}
		conn = getConn();
		conn.setAutoCommit(false);//给conn设置为手动提交
		tl.set(conn);
	}
	//提交事务
	public static void commitTransaction() throws SQLException{
		Connection conn = tl.get();
		conn.commit();//提交 事务
		conn.close();//表示当前的事务结束了，
		tl.remove();
		
	}
	//事务回滚
	public static void rollbackTransaction() throws SQLException{
		Connection conn = tl.get();
		conn.rollback();
		tl.remove();
	}
	
	//释放连接
	public static void releaseConnection(Connection connection) throws SQLException{
		Connection conn = tl.get();
		if(conn != null){
			conn.close();
		}
		if(conn != connection){
			connection.close();
		}
		
	}
	
	
	
	
	public static void main(String[] args) throws Exception {
		System.out.println(JdbcUtils.getConn());
	}
	
	
}
