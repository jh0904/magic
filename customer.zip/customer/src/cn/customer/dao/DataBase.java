package cn.customer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class DataBase {
	private Connection conn=null;
	private ResultSet rs=null;
	private PreparedStatement pstmt=null;
	//公共的查询
	public ResultSet Query(String sql,Object...param){
		try {
			conn=JdbcUtils.getConn();
			pstmt=conn.prepareStatement(sql);
			
			for (int i = 0; i < param.length; i++) {
				pstmt.setObject(i+1, param[i]);
			}
			 rs = pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	//增删改
	public int update(String sql,Object...param){
		int row=0;
		try {
			conn=JdbcUtils.getConn();
			pstmt=conn.prepareStatement(sql);
			for (int i = 0; i < param.length; i++) {
				pstmt.setObject(i+1, param[i]);
			}
			row=pstmt.executeUpdate();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return row;
	}
	public static void main(String[] args) {
		try {
			System.out.println(JdbcUtils.getConn());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
