package cn.customer.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.customer.entity.Customer;

public class CustomerDao extends DataBase{
	
	public void add(Customer c){
		String sql="insert into customer values(?,?,?,?,?,?,?)";
		Object[] parms={c.getCid(),c.getCname(),c.getSex(),c.getBirthday(),
				c.getCellphone(),c.getEmail(),c.getDescription()};
		super.update(sql, parms);
	}
	
	
	public List all(){
		String sql="select *from customer";
		ResultSet rs = Query(sql);
		List<Customer> list = new ArrayList<Customer>();
		Customer c=null;
		
		try {
			while(rs.next()){
				c=new Customer();
				c.setCid(rs.getString("cid"));
				c.setCname(rs.getString("cname"));
				c.setSex(rs.getString("sex"));
				c.setBirthday(rs.getString("birthday"));
				c.setCellphone(rs.getString("cellphone"));
				c.setEmail(rs.getString("email"));
				c.setDescription(rs.getString("description"));
				list.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
	
	public void delete(String cid) {
		String sql="delete from customer where cid=?";
		Object[] parms={cid};
		super.update(sql, parms);
	}
	public void sub(Customer c) {
		String sql="update customer set cname=?,sex=?,birthday=?,cellphone=?,email=?,description=? where cid=?";
		super.update(sql, c.getCname(),c.getSex(),c.getBirthday(),
				c.getCellphone(),c.getEmail(),c.getDescription(),c.getCid());
		
	}
	public Customer findOne(String cid){
			String sql="select * from customer where cid=?";
			Object[] parms={cid};
			ResultSet rs=Query(sql, parms);
			Customer c=new Customer();
			try {
				while(rs.next()){
					c.setCid(rs.getString("cid"));
					c.setCname(rs.getString("cname"));
					c.setSex(rs.getString("sex"));
					c.setBirthday(rs.getString("birthday"));
					c.setCellphone(rs.getString("cellphone"));
					c.setEmail(rs.getString("email"));
					c.setDescription(rs.getString("description"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return c;
		
	}
}
