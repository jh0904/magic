package cn.customer.servlet;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;


import cn.customer.dao.CustomerDao;
import cn.customer.entity.Customer;
import cn.customer.service.CustomerService;

@SuppressWarnings("serial")
public class CustomerServlet extends Aservlet{
	
	private  CustomerService service =new CustomerService();
	
	public String add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
		
			String cname=request.getParameter("cname");
			String sex=request.getParameter("sex");
			String birthday=request.getParameter("birthday");
			String cellphone=request.getParameter("cellphone");
			String email=request.getParameter("email");
			String description=request.getParameter("description");
			
			Customer c=new Customer();
			UUID uuid=UUID.randomUUID();
			String id=uuid.toString().replace("-", "");
			c.setCid(id);
			c.setCname(cname);
			c.setSex(sex);
			c.setBirthday(birthday);
			c.setCellphone(cellphone);
			c.setEmail(email);
			c.setDescription(description);
			
			service.add(c);	
			request.setAttribute("message", "恭喜，添加成功！！！");
			return "forward:/msg.jsp";
	}
	//查全部
	public  String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		List<Customer> all=service.findAll();
		request.setAttribute("list", all);
		return "forward:/list.jsp";
	}
	//编辑(查一个)
	public String edit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				request.setCharacterEncoding("UTF-8");
				response.setCharacterEncoding("UTF-8");
				String cid=request.getParameter("cid");
				Customer One = service.findOne(cid);
				request.setAttribute("one", One);
				return "forward:/edit.jsp";
	}
	//编辑提交
	public String sub(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			
			String cid=request.getParameter("cid");
			
			String cname=request.getParameter("cname");
			String sex=request.getParameter("sex");
			String birthday=request.getParameter("birthday");
			String cellphone=request.getParameter("cellphone");
			String email=request.getParameter("email");
			String description=request.getParameter("description");
			
			Customer c=new Customer();
			c.setCid(cid);
			c.setCname(cname);
			c.setSex(sex);
			c.setBirthday(birthday);
			c.setCellphone(cellphone);
			c.setEmail(email);
			c.setDescription(description);
			
			service.sub(c);
			
			request.setAttribute("message", "恭喜，修改成功！！！");
			return "forward:/msg.jsp";
	}
	//删除
	public  String delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String cid=request.getParameter("cid");
			service.delete(cid);
			request.setAttribute("message", "删除成功");
			return "forward:/msg.jsp";
	}
	public static void main(String[] args) {
		CustomerDao d=new CustomerDao();
		Customer a = d.findOne("100223");
		System.out.println(a.getCname());
	}
}
