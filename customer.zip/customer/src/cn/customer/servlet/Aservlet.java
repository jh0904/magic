package cn.customer.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class Aservlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException ,IOException {
		request.setCharacterEncoding("UTF-8");
		String MethodName=request.getParameter("method");
		try {
			Method method = this.getClass().getMethod(MethodName, HttpServletRequest.class,HttpServletResponse.class);
			String result = (String)method.invoke(this, request,response);
			if(result.contains(":")){
				int i=result.indexOf(":");
				String start=result.substring(0,i);
				String path=result.substring(i+1);
				
				if(start.equalsIgnoreCase("forward")){
					try {
						request.getRequestDispatcher(path).forward(request, response);
					} catch (ServletException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}else {
					try {
						response.sendRedirect(request.getContextPath()+path);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
	}
	
	
}
