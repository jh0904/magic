package cn.customer.service;

import java.util.List;

import cn.customer.dao.CustomerDao;
import cn.customer.entity.Customer;

public class CustomerService {
	private CustomerDao dao=new CustomerDao();
		public void add(Customer c){
			dao.add(c);
		}
		//
		public List<Customer> findAll(){
			List all = dao.all();
			return all;
		}
		//
		public void delete(String cid) {
			dao.delete(cid);
		}
		//
		public Customer findOne(String cid) {
			Customer f= dao.findOne(cid);
			return f;
		}
		//
		public void sub(Customer c) {
			dao.sub(c);
		}
}
